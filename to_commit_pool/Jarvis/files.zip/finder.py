#!/usr/bin/env python3
"""
finder.py  —  Git & Loose-Code Scanner for Windows
Author  : Naseer-fez
Purpose : Find all uncommitted / unpushed code and copy it to Desktop\to_commit_pool
Usage   : python finder.py [extra_path1] [extra_path2] ...
"""

import os
import sys
import shutil
import subprocess
import getpass
from pathlib import Path
from datetime import datetime

# ──────────────────────────────────────────────
# ANSI colour helpers (work on modern Windows 10+)
# ──────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    DIM     = "\033[2m"

def enable_ansi():
    """Enable ANSI escape codes on Windows."""
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)

def header(text):
    width = 70
    print(f"\n{C.BOLD}{C.CYAN}{'═' * width}{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}  {text}{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}{'═' * width}{C.RESET}")

def section(text):
    print(f"\n{C.BOLD}{C.BLUE}▶ {text}{C.RESET}")

def ok(text):
    print(f"  {C.GREEN}✔ {text}{C.RESET}")

def warn(text):
    print(f"  {C.YELLOW}⚠ {text}{C.RESET}")

def err(text):
    print(f"  {C.RED}✖ {text}{C.RESET}")

def info(text):
    print(f"  {C.DIM}{text}{C.RESET}")

# ──────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────
SKIP_DIRS = {
    "node_modules", ".git", "vendor", "__pycache__",
    "dist", "build", ".venv", "venv", ".tox", ".mypy_cache",
    ".pytest_cache", "coverage", ".next", "out", "target",
}

LOOSE_EXTENSIONS = {
    ".js", ".ts", ".jsx", ".tsx", ".py", ".java", ".cpp", ".c",
    ".h", ".hpp", ".html", ".css", ".scss", ".sass", ".go",
    ".rb", ".php", ".rs", ".swift", ".kt", ".cs", ".lua",
}

USERNAME    = os.environ.get("GITHUB_USERNAME") or getpass.getuser()
GITHUB_PAT  = os.environ.get("GITHUB_PAT", "")

def get_scan_roots(extra_paths):
    win_user = os.environ.get("USERNAME") or os.environ.get("USERPROFILE", "").split("\\")[-1] or getpass.getuser()
    base = Path(f"C:/Users/{win_user}")
    roots = [
        base / "Desktop",
        base / "Documents",
        base / "Downloads",
    ]
    for p in extra_paths:
        roots.append(Path(p))
    # filter to existing
    return [r for r in roots if r.exists()]

def get_desktop():
    win_user = os.environ.get("USERNAME") or getpass.getuser()
    return Path(f"C:/Users/{win_user}/Desktop")

POOL_NAME = "to_commit_pool"

# ──────────────────────────────────────────────
# GIT HELPERS
# ──────────────────────────────────────────────
def run_git(args, cwd):
    """Run a git command and return (stdout, stderr, returncode)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except FileNotFoundError:
        return "", "git not found", 1
    except Exception as e:
        return "", str(e), 1

def is_git_repo(path: Path) -> bool:
    _, _, code = run_git(["rev-parse", "--is-inside-work-tree"], path)
    return code == 0

def get_repo_status(repo_path: Path):
    """
    Returns dict with:
      modified  : list of modified-but-unstaged files
      staged    : list of staged-but-uncommitted files
      untracked : list of untracked files
      unpushed  : list of commits ahead of remote
      branch    : current branch name
      remote    : remote URL (or None)
      has_remote: bool
    """
    status = {
        "modified":  [],
        "staged":    [],
        "untracked": [],
        "unpushed":  [],
        "branch":    "unknown",
        "remote":    None,
        "has_remote": False,
    }

    # Branch
    branch_out, _, _ = run_git(["branch", "--show-current"], repo_path)
    status["branch"] = branch_out or "HEAD (detached)"

    # Porcelain status
    out, _, code = run_git(["status", "--porcelain=v1"], repo_path)
    if code == 0:
        for line in out.splitlines():
            if len(line) < 2:
                continue
            xy   = line[:2]
            path = line[3:].strip().strip('"')
            # Staged (index modified)
            if xy[0] in ("M", "A", "D", "R", "C") and xy[0] != " ":
                status["staged"].append(path)
            # Modified working tree
            if xy[1] in ("M", "D"):
                status["modified"].append(path)
            # Untracked
            if xy == "??":
                status["untracked"].append(path)

    # Remote
    remote_out, _, _ = run_git(["remote", "get-url", "origin"], repo_path)
    if remote_out:
        status["remote"]    = remote_out
        status["has_remote"] = True

    # Unpushed commits
    if status["has_remote"]:
        # fetch silently (skip if no network / PAT)
        run_git(["fetch", "--quiet"], repo_path)
        log_out, _, log_code = run_git(
            ["log", f"origin/{status['branch']}..HEAD", "--oneline"],
            repo_path,
        )
        if log_code == 0 and log_out:
            status["unpushed"] = log_out.splitlines()
    else:
        # no remote — check commits on branch
        log_out, _, log_code = run_git(["log", "--oneline"], repo_path)
        if log_code == 0 and log_out:
            status["unpushed"] = log_out.splitlines()

    return status

# ──────────────────────────────────────────────
# DIRECTORY WALKER
# ──────────────────────────────────────────────
def walk(root: Path):
    """
    Yield (path, is_git_root).
    Stops descending into .git / skip dirs,
    and stops descending into a repo once its root is yielded.
    """
    try:
        entries = list(root.iterdir())
    except PermissionError:
        return

    # Check if THIS directory is a git repo
    if (root / ".git").exists():
        yield root, True
        return   # don't recurse inside a repo for repo-detection purposes

    for entry in entries:
        if not entry.is_dir():
            continue
        if entry.name in SKIP_DIRS:
            continue
        yield from walk(entry)

def find_loose_files(root: Path, git_repo_paths: set):
    """
    Find loose code files in `root` that are NOT inside any known git repo.
    """
    loose = []

    def _walk(path: Path):
        try:
            entries = list(path.iterdir())
        except PermissionError:
            return
        for entry in entries:
            if entry.is_dir():
                if entry.name in SKIP_DIRS:
                    continue
                # skip if this dir is inside a git repo we already catalogued
                if any(str(entry).startswith(str(gr)) for gr in git_repo_paths):
                    continue
                _walk(entry)
            elif entry.is_file():
                if entry.suffix.lower() in LOOSE_EXTENSIONS:
                    # confirm not inside a git repo
                    if not any(str(entry).startswith(str(gr)) for gr in git_repo_paths):
                        loose.append(entry)

    _walk(root)
    return loose

# ──────────────────────────────────────────────
# COPY TO POOL
# ──────────────────────────────────────────────
def copy_to_pool(src: Path, pool_root: Path, relative_base: Path):
    """Copy src file into pool_root, preserving relative directory structure."""
    try:
        rel = src.relative_to(relative_base)
    except ValueError:
        rel = Path(src.name)

    dest = pool_root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)

    # Only copy if newer or not present
    if dest.exists():
        src_mtime  = src.stat().st_mtime
        dest_mtime = dest.stat().st_mtime
        if src_mtime <= dest_mtime:
            return False   # unchanged

    shutil.copy2(str(src), str(dest))
    return True   # newly copied / updated

# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────
def main():
    enable_ansi()

    extra_paths = sys.argv[1:]
    scan_roots  = get_scan_roots(extra_paths)
    desktop     = get_desktop()
    pool_root   = desktop / POOL_NAME

    # ── Banner ──────────────────────────────────
    header(f"Git & Loose-Code Scanner  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  {C.MAGENTA}GitHub user : {C.BOLD}{USERNAME}{C.RESET}")
    print(f"  {C.MAGENTA}PAT loaded  : {C.BOLD}{'YES ✔' if GITHUB_PAT else 'NO — set GITHUB_PAT env var'}{C.RESET}")
    print(f"  {C.MAGENTA}Pool folder : {C.BOLD}{pool_root}{C.RESET}")
    section("Scan roots")
    for r in scan_roots:
        ok(str(r))

    # ── Discover repos ───────────────────────────
    section("Discovering git repositories…")
    git_repos = []
    for root in scan_roots:
        for repo_path, _ in walk(root):
            git_repos.append(repo_path)

    print(f"  Found {C.BOLD}{C.GREEN}{len(git_repos)}{C.RESET} git repositories.\n")

    # ── Analyse each repo ────────────────────────
    all_dirty_files   = []   # (absolute_path, repo_root)
    total_modified    = 0
    total_staged      = 0
    total_untracked   = 0
    total_unpushed    = 0

    git_repo_paths = set(git_repos)

    for repo in git_repos:
        st = get_repo_status(repo)
        dirty = st["modified"] or st["staged"] or st["untracked"] or st["unpushed"]
        if not dirty:
            continue

        # Print repo header
        branch_col = C.GREEN if st["has_remote"] else C.YELLOW
        print(f"\n  {C.BOLD}{C.WHITE}{repo}{C.RESET}  "
              f"{branch_col}[{st['branch']}]{C.RESET}  "
              f"{C.DIM}{'→ ' + st['remote'] if st['remote'] else '(no remote)'}{C.RESET}")

        def _report(label, colour, items):
            if items:
                print(f"    {colour}{label} ({len(items)}):{C.RESET}")
                for f in items[:10]:
                    print(f"      {C.DIM}{f}{C.RESET}")
                if len(items) > 10:
                    print(f"      {C.DIM}… and {len(items)-10} more{C.RESET}")

        _report("Modified (unstaged)",  C.YELLOW,  st["modified"])
        _report("Staged (uncommitted)", C.MAGENTA,  st["staged"])
        _report("Untracked",            C.RED,      st["untracked"])
        _report("Unpushed commits",     C.CYAN,     st["unpushed"])

        total_modified  += len(st["modified"])
        total_staged    += len(st["staged"])
        total_untracked += len(st["untracked"])
        total_unpushed  += len(st["unpushed"])

        # Collect physical files for copying
        for rel_f in (st["modified"] + st["staged"] + st["untracked"]):
            abs_f = repo / rel_f
            if abs_f.exists() and abs_f.is_file():
                all_dirty_files.append((abs_f, repo))

    # ── Loose files ──────────────────────────────
    section("Scanning for loose code files (outside any git repo)…")
    all_loose = []
    for root in scan_roots:
        loose = find_loose_files(root, git_repo_paths)
        all_loose.extend([(f, root) for f in loose])

    if all_loose:
        print(f"  Found {C.BOLD}{C.RED}{len(all_loose)}{C.RESET} loose code files:\n")
        for f, base in all_loose[:30]:
            print(f"    {C.RED}{f}{C.RESET}")
        if len(all_loose) > 30:
            print(f"    {C.DIM}… and {len(all_loose)-30} more{C.RESET}")
    else:
        ok("No loose code files found outside git repos.")

    # ── Copy to pool ─────────────────────────────
    section(f"Updating pool → {pool_root}")
    pool_root.mkdir(parents=True, exist_ok=True)

    copied   = 0
    skipped  = 0

    for abs_f, base in all_dirty_files + all_loose:
        if copy_to_pool(abs_f, pool_root, base):
            copied += 1
        else:
            skipped += 1

    ok(f"{copied} files copied/updated, {skipped} already up-to-date.")

    # ── Write a manifest ─────────────────────────
    manifest_path = pool_root / "_MANIFEST.txt"
    with open(manifest_path, "w", encoding="utf-8") as mf:
        mf.write(f"# to_commit_pool manifest — generated {datetime.now().isoformat()}\n")
        mf.write(f"# GitHub user : {USERNAME}\n\n")
        mf.write("## Dirty git files\n")
        for abs_f, _ in all_dirty_files:
            mf.write(f"{abs_f}\n")
        mf.write("\n## Loose code files\n")
        for abs_f, _ in all_loose:
            mf.write(f"{abs_f}\n")

    # ── Final summary ────────────────────────────
    header("SUMMARY")
    rows = [
        ("Git repos scanned",          len(git_repos),                   C.CYAN),
        ("Modified (unstaged) files",  total_modified,                   C.YELLOW),
        ("Staged (uncommitted) files", total_staged,                     C.MAGENTA),
        ("Untracked files",            total_untracked,                  C.RED),
        ("Unpushed commit messages",   total_unpushed,                   C.CYAN),
        ("Loose code files",           len(all_loose),                   C.RED),
        ("Files copied to pool",       copied,                           C.GREEN),
        ("Files already up-to-date",   skipped,                          C.DIM),
    ]
    for label, count, colour in rows:
        bar = "█" * min(count, 40)
        print(f"  {colour}{label:<30} {C.BOLD}{count:>5}  {bar}{C.RESET}")

    total_action = total_modified + total_staged + total_untracked + len(all_loose)
    print(f"\n  {C.BOLD}{C.WHITE}Total files needing attention : {total_action}{C.RESET}")
    print(f"  {C.BOLD}{C.GREEN}Pool location : {pool_root}{C.RESET}")
    print(f"  {C.DIM}Manifest : {manifest_path}{C.RESET}\n")

    if total_action == 0:
        print(f"  {C.GREEN}{C.BOLD}🎉 Everything is clean! Nothing to commit.{C.RESET}\n")
    else:
        print(f"  {C.YELLOW}{C.BOLD}⚡ Run the GitHub Actions workflow to commit these files automatically.{C.RESET}\n")

if __name__ == "__main__":
    main()
